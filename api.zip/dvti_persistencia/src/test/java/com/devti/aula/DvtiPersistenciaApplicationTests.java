package com.devti.aula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DvtiPersistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
